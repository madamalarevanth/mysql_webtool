A Pen created at CodePen.io. You can find this one at https://codepen.io/vineethtr/pen/PqaPox.

 A Material Login form concept with social Signup